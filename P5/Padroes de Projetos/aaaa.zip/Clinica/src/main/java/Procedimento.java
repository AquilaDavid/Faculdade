public class Procedimento {

	private TipoProcedimento tipoProcedimento;

	public Procedimento(TipoProcedimento tipoProcedimento) {
		this.tipoProcedimento = tipoProcedimento;
	}

	public TipoProcedimento getTipoProcedimento() {
		return this.tipoProcedimento;
	}

}
