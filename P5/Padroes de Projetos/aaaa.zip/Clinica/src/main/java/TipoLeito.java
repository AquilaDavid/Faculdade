public enum TipoLeito {
	ENFERMARIA, APARTAMENTO;
}
