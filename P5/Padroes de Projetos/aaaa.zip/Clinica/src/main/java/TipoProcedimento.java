public enum TipoProcedimento {
	BASICO, COMUM, AVANCADO
}
